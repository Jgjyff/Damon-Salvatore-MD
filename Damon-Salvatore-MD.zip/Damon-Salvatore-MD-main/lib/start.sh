while true
do
echo "Starting Damon-Salvatore-MD!"
node .
done